import React, { useState, useRef } from 'react';
import { Upload, Camera, FileText, AlertTriangle, Shield, CheckCircle } from 'lucide-react';

const HomePage: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [showCamera, setShowCamera] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewUrl(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedImage) return;
    
    setIsAnalyzing(true);
    // Simulate API call - replace with actual backend call
    setTimeout(() => {
      setAnalysisResult({
        stage: 2,
        confidence: 87,
        riskLevel: 'Moderate',
        recommendations: [
          'Schedule regular follow-up examinations',
          'Monitor blood glucose levels closely',
          'Consult with an ophthalmologist within 6 months'
        ]
      });
      setIsAnalyzing(false);
    }, 3000);
  };

  const getRiskColor = (risk: string) => {
    switch (risk?.toLowerCase()) {
      case 'low': return 'text-green-600 bg-green-50';
      case 'moderate': return 'text-yellow-600 bg-yellow-50';
      case 'high': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="healthcare-container py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-healthcare-blue-600 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">OpthalmoAI</h1>
                <p className="text-sm text-gray-600">AI-Driven Diabetic Retinopathy Screening</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Medical Disclaimer */}
      <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-6">
        <div className="healthcare-container">
          <div className="flex items-start">
            <AlertTriangle className="w-5 h-5 text-amber-400 mt-0.5 mr-3 flex-shrink-0" />
            <div className="text-sm text-amber-800">
              <p className="font-semibold">Medical Disclaimer</p>
              <p>This is an assistive screening tool and is NOT a substitute for professional medical diagnosis. 
              Always consult with a qualified healthcare professional for proper medical evaluation and treatment.</p>
            </div>
          </div>
        </div>
      </div>

      <main className="healthcare-container py-8">
        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Diabetic Retinopathy Screening
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Upload a retinal fundus image or capture one using your camera for AI-powered analysis 
              to detect potential signs of diabetic retinopathy.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Upload Section */}
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">Upload Retinal Image</h3>
              
              {!previewUrl ? (
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-healthcare-blue-400 transition-colors">
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">
                    Click to upload or drag and drop your retinal fundus image
                  </p>
                  <div className="space-y-2">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="btn-primary"
                    >
                      Choose Image
                    </button>
                    <button
                      onClick={() => setShowCamera(true)}
                      className="btn-secondary ml-3"
                    >
                      <Camera className="w-4 h-4 mr-2 inline" />
                      Use Camera
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mt-3">
                    Supported formats: JPEG, PNG, BMP (Max 10MB)
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative">
                    <img
                      src={previewUrl}
                      alt="Selected retinal image"
                      className="w-full h-64 object-cover rounded-lg"
                    />
                    <button
                      onClick={() => {
                        setPreviewUrl(null);
                        setSelectedImage(null);
                        setAnalysisResult(null);
                      }}
                      className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-red-600"
                    >
                      ×
                    </button>
                  </div>
                  
                  <button
                    onClick={handleAnalyze}
                    disabled={isAnalyzing}
                    className="btn-primary w-full"
                  >
                    {isAnalyzing ? 'Analyzing...' : 'Analyze Image'}
                  </button>
                </div>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>

            {/* Results Section */}
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">Analysis Results</h3>
              
              {!analysisResult && !isAnalyzing ? (
                <div className="text-center py-12">
                  <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Upload and analyze an image to see results</p>
                </div>
              ) : isAnalyzing ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-healthcare-blue-600 mx-auto mb-4"></div>
                  <p className="text-gray-600">Analyzing retinal image...</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Stage and Confidence */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600">Detected Stage</p>
                      <p className="text-2xl font-bold text-gray-900">
                        Stage {analysisResult.stage}
                      </p>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600">Confidence</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {analysisResult.confidence}%
                      </p>
                    </div>
                  </div>

                  {/* Risk Level */}
                  <div className="text-center">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getRiskColor(analysisResult.riskLevel)}`}>
                      Risk Level: {analysisResult.riskLevel}
                    </span>
                  </div>

                  {/* Recommendations */}
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Recommendations:</h4>
                    <div className="space-y-2">
                      {analysisResult.recommendations.map((rec: string, index: number) => (
                        <div key={index} className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-healthcare-green-500 mr-2 flex-shrink-0 mt-0.5" />
                          <p className="text-sm text-gray-700">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex space-x-3">
                    <button className="btn-primary flex-1">
                      Download Report
                    </button>
                    <button className="btn-secondary flex-1">
                      Print Results
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Information Cards */}
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            <div className="card text-center">
              <div className="w-12 h-12 bg-healthcare-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Shield className="w-6 h-6 text-healthcare-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Secure & Private</h3>
              <p className="text-sm text-gray-600">
                Your images are processed securely and not stored permanently
              </p>
            </div>
            
            <div className="card text-center">
              <div className="w-12 h-12 bg-healthcare-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-6 h-6 text-healthcare-green-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">AI-Powered</h3>
              <p className="text-sm text-gray-600">
                Advanced deep learning models trained on medical datasets
              </p>
            </div>
            
            <div className="card text-center">
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="w-6 h-6 text-amber-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Professional Guidance</h3>
              <p className="text-sm text-gray-600">
                Always consult healthcare professionals for medical decisions
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="healthcare-container py-8">
          <div className="text-center text-gray-600">
            <p className="text-sm">
              © 2025 OpthalmoAI. This tool is for screening purposes only and should not replace professional medical advice.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;